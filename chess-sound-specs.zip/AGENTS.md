# Chessboard Sound Web App AGENTS

Last updated: 2025-09-12T22:44:21.972056Z

This document explains how to build the web app. It contains goals, format specs, algorithms, and acceptance criteria. The start position compact string is included at the end.

## Goals

Fast recognition of position feeling black versus white.
Three game sources. Start setting. Random realistic. Endgame near mate.
All configuration lives in JSON.
Web app only. No MIDI.
One game step is a single compact string.

## Compact format

Two bytes per cell. Four hex chars per cell. 64 cells. 256 hex chars total.
Byte one is a piece code. 00 means empty. White pieces start at 0x10. Black pieces start at 0x20. Index inside the byte. 01 pawn. 02 knight. 03 bishop. 04 rook. 05 queen. 06 king.
Byte two is flags. Bit 0 captured in last move. Bit 1 moved in last move. Bit 2 gives check. Bit 3 moved earlier. Bits 4 to 7 reserved.
Traversal order a8 to h8 then a7 to h7 to a1 to h1.

## Presets

Harmonic Layers. Rhythm Focus. Electro Scene. Ambient Clouds. Choir Hint.
Each preset contains engine and mapping.

## Key algorithms

Material balance and intensity. Tempo from intensity. Board to sound mapping.
Timeline scrub and tick loop.

## Acceptance criteria

Start setting plays with any preset.
Random realistic generates a legal position.
Endgame near mate generates a mate in three or less when engine is active.
Tick interval control works from 0.25 to 5 seconds.
PGN import works and history scrub works.

## Start position compact string

```
2400220023002500260023002200240021002100210021002100210021002100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001100110011001100110011001100110014001200130015001600130012001400
```